import React, { useState } from 'react';
import './Home.css';
import { useNavigate } from 'react-router-dom';


export default function Home() {

    const navigate = useNavigate();
    const [category, setCategory] = useState('');
    const [state, setState] = useState('');
    const [url, setUrl] = useState('');
    const [gender, setGender] = useState('');

    const handleSubmit = (event) => {
        event.preventDefault();

        console.log(url);
        console.log(category);
        console.log(state);

        navigate(`/examResult?url=${url}&state=${state}&category=${category}&gender=${gender}`);
    };


    return (
        <div className="form-page">
            <h1>Check your Marks & Rank</h1>
            <form onSubmit={handleSubmit} className='form-container'>
                <div className='input1'>
                    <label htmlFor="url">Akswer key url:</label>
                    <input
                        type="text"
                        id="url"
                        name="url"
                        value={url}
                        onChange={(event) =>
                            setUrl(event.target.value)
                        }
                        required
                    />
                </div>
                <div className='input1'>
                    <label htmlFor="category">Category:</label>
                    <select
                        type="text"
                        id="category"
                        name="category"
                        value={category}
                        onChange={(event) =>
                            setCategory(event.target.value)
                        }>
                        <option value="category">Category</option>
                        <option value="UR">UR</option>
                        <option value="OBC">OBC</option>
                        <option value="EWS">EWS</option>
                        <option value="SC">SC</option>
                        <option value="ST">ST</option>
                        required
                    </select>

                </div>
                <div className='input1'>
                    <label htmlFor="gender">Gender:</label>

                    <select
                        type="text"
                        id="gender"
                        name="gender"
                        value={gender}
                        onChange={(event) =>
                            setState(event.target.value)
                        }>
                        <option value="gender">Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        required
                    </select>
                </div>

                <div className='input1'>
                    <label htmlFor="state">State:</label>

                    <select
                        type="text"
                        id="state"
                        name="state"
                        value={state}
                        onChange={(event) =>
                            setGender(event.target.value)
                        }>
                        <option value="state">State</option>

                        <option value="Karnataka">Karnataka</option>
                    </select>
                </div>

                <button type="submit">Submit</button>
            </form >
        </div >);

}